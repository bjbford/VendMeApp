package ss_3.iastate.edu.vendme;

/**
 * Constants used for server connection with PHP.
 * - Created by JB on 2/20/18.
 */
public class Constants {

    private static final String ROOT_URL = "http://proj-309-ss-3.cs.iastate.edu/android/v1/";

    public static final String URL_REGISTER = ROOT_URL+"createMachine.php";



}
